using System;
using System.Drawing;
using System.Windows.Forms;
using UbuntuSimulator_Csharp.FileSystem;
using UbuntuSimulator_Csharp.Core;

namespace UbuntuSimulator_Csharp
{
    public class TerminalForm : Form
    {
        private TextBox outputBox;
        private TextBox inputBox;
        private Process currentProcess;

        public TerminalForm()
        {
            this.Text = "Terminal - user@ubuntu";
            this.Size = new Size(700, 450);
            this.BackColor = Color.FromArgb(48, 10, 36);

            outputBox = new TextBox
            {
                Multiline = true,
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(48, 10, 36),
                ForeColor = Color.LightGray,
                ReadOnly = true,
                Font = new Font("Consolas", 12),
                ScrollBars = ScrollBars.Vertical,
                BorderStyle = BorderStyle.None
            };

            inputBox = new TextBox
            {
                Dock = DockStyle.Bottom,
                BackColor = Color.FromArgb(48, 10, 36),
                ForeColor = Color.White,
                Font = new Font("Consolas", 12),
                BorderStyle = BorderStyle.FixedSingle
            };
            inputBox.KeyDown += InputBox_KeyDown;

            this.Controls.Add(outputBox);
            this.Controls.Add(inputBox);

            Log("Ubuntu Simülasyonu (OOP Projesi)");
            Log("Komutları görmek için 'help' yazın.\n");
        }

        private void Log(string message)
        {
            outputBox.AppendText(message + Environment.NewLine);
        }

        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // prevent ding
                string cmd = inputBox.Text.Trim();
                inputBox.Text = "";
                Log($"user@ubuntu:~$ {cmd}");
                ProcessCommand(cmd);
            }
        }

        private void ProcessCommand(string cmd)
        {
            var parts = cmd.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0) return;

            string action = parts[0].ToLower();
            try
            {
                switch (action)
                {
                    case "help":
                        Log("Komutlar: ls, mkdir <isim>, touch <isim>, ps, kill <pid>, clear");
                        break;
                    case "clear":
                        outputBox.Clear();
                        break;
                    case "ls":
                        foreach (var child in VirtualFileSystem.Instance.CurrentDirectory.Children)
                        {
                            Log($" {(child.IsDirectory ? "<DIR>" : "     ")} \t{child.Name}");
                        }
                        break;
                    case "mkdir":
                        if (parts.Length > 1) { VirtualFileSystem.Instance.CreateDirectory(parts[1]); Log($"Klasör '{parts[1]}' oluşturuldu."); }
                        else Log("usage: mkdir <isim>");
                        break;
                    case "touch":
                        if (parts.Length > 1) { VirtualFileSystem.Instance.CreateFile(parts[1], ""); Log($"Dosya '{parts[1]}' oluşturuldu."); }
                        else Log("usage: touch <isim>");
                        break;
                    case "ps":
                        Log("PID\tDURUM\t\tISIM");
                        foreach (var p in ProcessManager.Instance.GetProcesses())
                        {
                            Log($"{p.PId}\t{p.State}\t\t{p.Name}");
                        }
                        break;
                    case "kill":
                        if (parts.Length > 1 && int.TryParse(parts[1], out int pid))
                        {
                            ProcessManager.Instance.KillProcess(pid);
                            Log($"Süreç {pid} sonlandırıldı.");
                        }
                        else Log("usage: kill <pid>");
                        break;
                    default:
                        Log($"Komut bulunamadı: {action}");
                        break;
                }
            }
            catch (Exception ex)
            {
                Log($"Error: {ex.Message}");
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            currentProcess = ProcessManager.Instance.StartProcess("Terminal Konsolu");
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);
            if(currentProcess != null)
                ProcessManager.Instance.KillProcess(currentProcess.PId);
        }
    }
}
