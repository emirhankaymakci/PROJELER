using System.Collections.Generic;
using System.Linq;

namespace UbuntuSimulator_Csharp.FileSystem
{
    public class DirectoryEntity : FileSystemNode
    {
        public List<FileSystemNode> Children { get; private set; } = new List<FileSystemNode>();

        public DirectoryEntity(string name) : base(name) { }

        public override bool IsDirectory => true;

        public void AddChild(FileSystemNode node)
        {
            node.Parent = this;
            Children.Add(node);
        }

        public void RemoveChild(string name)
        {
            var child = Children.FirstOrDefault(c => c.Name == name);
            if (child != null)
            {
                Children.Remove(child);
            }
        }
    }
}
