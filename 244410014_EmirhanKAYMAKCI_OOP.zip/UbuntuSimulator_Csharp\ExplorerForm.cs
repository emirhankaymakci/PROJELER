using System;
using System.Drawing;
using System.Windows.Forms;
using UbuntuSimulator_Csharp.FileSystem;
using UbuntuSimulator_Csharp.Core;

namespace UbuntuSimulator_Csharp
{
    public class ExplorerForm : Form
    {
        private ListBox itemsList;
        private Process currentProcess;
        private Button copyBtn, pasteBtn, newFolderBtn;

        public ExplorerForm()
        {
            this.Text = "Ubuntu Dosya Yöneticisi";
            this.Size = new Size(600, 400);
            this.BackColor = Color.WhiteSmoke;

            var topPanel = new Panel { Dock = DockStyle.Top, Height = 40, BackColor = Color.LightGray };
            copyBtn = new Button { Text = "Kopyala", Left = 10, Top = 5, Width=80, BackColor=Color.White };
            pasteBtn = new Button { Text = "Yapıştır", Left = 100, Top = 5, Width=80, BackColor=Color.White };
            newFolderBtn = new Button { Text = "Yeni Klasör", Left = 190, Top = 5, Width=100, BackColor=Color.White };
            
            copyBtn.Click += CopyBtn_Click;
            pasteBtn.Click += PasteBtn_Click;
            newFolderBtn.Click += NewFolderBtn_Click;

            topPanel.Controls.Add(copyBtn);
            topPanel.Controls.Add(pasteBtn);
            topPanel.Controls.Add(newFolderBtn);

            itemsList = new ListBox { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 12), BorderStyle=BorderStyle.None };
            
            this.Controls.Add(itemsList);
            this.Controls.Add(topPanel);

            RefreshList();
        }

        private void RefreshList()
        {
            itemsList.Items.Clear();
            foreach (var child in VirtualFileSystem.Instance.CurrentDirectory.Children)
            {
                itemsList.Items.Add($"{(child.IsDirectory ? "📁" : "📄")} {child.Name}");
            }
        }

        private void CopyBtn_Click(object sender, EventArgs e)
        {
            if (itemsList.SelectedItem == null) return;
            string name = itemsList.SelectedItem.ToString().Substring(3); // Remove icon
            var node = VirtualFileSystem.Instance.GetNode(name);
            if (node != null)
            {
                VirtualFileSystem.Instance.Clipboard = node;
                MessageBox.Show($"'{name}' kopyalandı.");
            }
        }

        private void PasteBtn_Click(object sender, EventArgs e)
        {
            var cb = VirtualFileSystem.Instance.Clipboard;
            if (cb != null)
            {
                string newName = cb.Name + "_kopya";
                if (cb.IsDirectory)
                {
                    VirtualFileSystem.Instance.CreateDirectory(newName);
                }
                else
                {
                    VirtualFileSystem.Instance.CreateFile(newName, ((FileEntity)cb).Content);
                }
                RefreshList();
            }
        }

        private void NewFolderBtn_Click(object sender, EventArgs e)
        {
            string name = "YeniKlasör_" + new Random().Next(100, 999);
            VirtualFileSystem.Instance.CreateDirectory(name);
            RefreshList();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            currentProcess = ProcessManager.Instance.StartProcess("Dosya Yoneticisi");
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);
            if (currentProcess != null)
                ProcessManager.Instance.KillProcess(currentProcess.PId);
        }
    }
}
