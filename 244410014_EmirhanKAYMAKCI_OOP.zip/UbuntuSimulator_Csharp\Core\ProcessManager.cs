using System;
using System.Collections.Generic;
using System.Linq;

namespace UbuntuSimulator_Csharp.Core
{
    public class ProcessManager
    {
        private static ProcessManager _instance;
        public static ProcessManager Instance => _instance ??= new ProcessManager();

        private List<Process> _processes = new List<Process>();
        private int _nextPid = 1;

        private ProcessManager() { }

        public Process StartProcess(string name)
        {
            var p = new Process(_nextPid++, name);
            _processes.Add(p);
            return p;
        }

        public void KillProcess(int pid)
        {
            var p = _processes.FirstOrDefault(x => x.PId == pid);
            if (p != null)
            {
                p.State = "Terminated";
                _processes.Remove(p);
            }
        }

        public List<Process> GetProcesses() => new List<Process>(_processes);
    }
}
