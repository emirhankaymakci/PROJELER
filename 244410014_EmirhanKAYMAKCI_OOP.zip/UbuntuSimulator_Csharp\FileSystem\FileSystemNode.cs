namespace UbuntuSimulator_Csharp.FileSystem
{
    public abstract class FileSystemNode
    {
        public string Name { get; set; }
        public DirectoryEntity Parent { get; set; }

        public FileSystemNode(string name)
        {
            Name = name;
        }

        public abstract bool IsDirectory { get; }
        public string FullPath => Parent == null ? Name : Parent.FullPath + "/" + Name;
    }
}
