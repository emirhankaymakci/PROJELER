using System;

namespace UbuntuSimulator_Csharp.FileSystem
{
    public class VirtualFileSystem
    {
        public DirectoryEntity Root { get; private set; }
        public DirectoryEntity CurrentDirectory { get; set; }

        public FileSystemNode Clipboard { get; set; }

        private static VirtualFileSystem _instance;
        public static VirtualFileSystem Instance => _instance ??= new VirtualFileSystem();

        private VirtualFileSystem()
        {
            Root = new DirectoryEntity("~");
            CurrentDirectory = Root;
        }

        public void CreateFile(string name, string content = "")
        {
            CurrentDirectory.AddChild(new FileEntity(name, content));
        }

        public void CreateDirectory(string name)
        {
            CurrentDirectory.AddChild(new DirectoryEntity(name));
        }

        public FileSystemNode GetNode(string name)
        {
            foreach(var child in CurrentDirectory.Children)
            {
                if(child.Name == name) return child;
            }
            return null;
        }
    }
}
