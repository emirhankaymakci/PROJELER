namespace UbuntuSimulator_Csharp.FileSystem
{
    public class FileEntity : FileSystemNode
    {
        public string Content { get; set; }

        public FileEntity(string name, string content = "") : base(name)
        {
            Content = content;
        }

        public override bool IsDirectory => false;
    }
}
