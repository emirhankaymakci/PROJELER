using System;
using System.Drawing;
using System.Windows.Forms;
using UbuntuSimulator_Csharp.Core;

namespace UbuntuSimulator_Csharp
{
    public partial class Form1 : Form
    {
        private Panel dockPanel;
        private Button btnTerminal;
        private Button btnExplorer;

        public Form1()
        {
            InitializeComponent();
            SetupDesktop();
        }

        private void SetupDesktop()
        {
            this.Text = "Ubuntu İşletim Sistemi Simülasyonu";
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            this.BackColor = Color.FromArgb(48, 10, 36);

            dockPanel = new Panel
            {
                Dock = DockStyle.Left,
                Width = 80,
                BackColor = Color.FromArgb(30, 30, 30) // Koyu dock
            };

            btnExplorer = new Button
            {
                Text = "📁",
                Font = new Font("Segoe UI Emoji", 24),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Width = 70,
                Height = 70,
                Top = 20,
                Left = 5
            };
            btnExplorer.FlatAppearance.BorderSize = 0;
            btnExplorer.Click += BtnExplorer_Click;

            btnTerminal = new Button
            {
                Text = "💻",
                Font = new Font("Segoe UI Emoji", 24),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Width = 70,
                Height = 70,
                Top = 100,
                Left = 5
            };
            btnTerminal.FlatAppearance.BorderSize = 0;
            btnTerminal.Click += BtnTerminal_Click;

            var btnExit = new Button
            {
                Text = "⏻",
                Font = new Font("Segoe UI Emoji", 22),
                BackColor = Color.Transparent,
                ForeColor = Color.Red,
                FlatStyle = FlatStyle.Flat,
                Width = 70,
                Height = 60,
                Dock = DockStyle.Bottom
            };
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.Click += (s, e) => this.Close();

            dockPanel.Controls.Add(btnExplorer);
            dockPanel.Controls.Add(btnTerminal);
            dockPanel.Controls.Add(btnExit);

            this.Controls.Add(dockPanel);
        }

        private void BtnExplorer_Click(object sender, EventArgs e)
        {
            var explorer = new ExplorerForm();
            explorer.Show();
        }

        private void BtnTerminal_Click(object sender, EventArgs e)
        {
            var terminal = new TerminalForm();
            terminal.Show();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            ProcessManager.Instance.StartProcess("Desktop");
        }
    }
}
