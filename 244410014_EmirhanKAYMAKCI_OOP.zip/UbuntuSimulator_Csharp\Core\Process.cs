using System;

namespace UbuntuSimulator_Csharp.Core
{
    public class Process
    {
        public int PId { get; private set; }
        public string Name { get; private set; }
        public string State { get; set; }

        public Process(int pid, string name)
        {
            PId = pid;
            Name = name;
            State = "Running";
        }
    }
}
